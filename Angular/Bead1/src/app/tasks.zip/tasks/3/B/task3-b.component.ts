import { Component } from '@angular/core';

@Component({
  selector: 'app-task3-b',
  templateUrl: './task3-b.component.html',
  styleUrls: ['./task3-b.component.less']
})
export class Task3BComponent {

  constructor() { }
}
