import { Component } from '@angular/core';

@Component({
  selector: 'app-task3-a',
  templateUrl: './task3-a.component.html',
  styleUrls: ['./task3-a.component.less']
})
export class Task3AComponent {

  constructor() { }

}
