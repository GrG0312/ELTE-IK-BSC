import { Component } from '@angular/core';

@Component({
  selector: 'app-task4-b',
  templateUrl: './task4-b.component.html',
  styleUrls: ['./task4-b.component.less']
})
export class Task4BComponent {

  constructor() { }
}
