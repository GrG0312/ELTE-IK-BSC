import { Component } from '@angular/core';

@Component({
  selector: 'app-task5-b',
  templateUrl: './task5-b.component.html',
  styleUrls: ['./task5-b.component.less']
})
export class Task5BComponent {

  constructor() { }
}
