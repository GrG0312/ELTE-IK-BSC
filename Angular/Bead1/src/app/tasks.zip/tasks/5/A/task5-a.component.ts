import { Component } from '@angular/core';

@Component({
  selector: 'app-task5-a',
  templateUrl: './task5-a.component.html',
  styleUrls: ['./task5-a.component.less']
})
export class Task5AComponent {

  constructor() { }

}
