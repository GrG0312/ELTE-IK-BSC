﻿using Avalonia.Controls;

namespace BaseDefense.Views;

public partial class MainView : UserControl
{
    public MainView()
    {
        InitializeComponent();
    }
}
