﻿using Avalonia.Controls;

namespace BaseDefense.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}
