﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace BaseDefense.ViewModels;

public class ViewModelBase : ObservableObject
{
}
